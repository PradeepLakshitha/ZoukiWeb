<?php
session_start();
include 'db_connection.php';

// Auto-login using Remember Me cookie
if (isset($_COOKIE['username'])) {
    $_SESSION['username'] = $_COOKIE['username'];
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $remember = isset($_POST['remember']);

    $sql = "SELECT * FROM z_user WHERE username = ? AND status = 'active'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['userID'] = $row['userID'];
            $_SESSION['username'] = $row['username'];

            // Set a Remember Me cookie
            if ($remember) {
                setcookie("username", $username, time() + (86400 * 30), "/");
            }

            $_SESSION['success'] = "Login successful!";
            header("Location: dashboard.php");
            exit();
        } else {
            $_SESSION['error'] = "Invalid password!";
        }
    } else {
        $_SESSION['error'] = "Invalid username or account inactive!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZOUKI User Login</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SweetAlert2 for Beautiful Notifications -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="d-flex flex-column min-vh-100 position-relative">
<?php include 'db_connection.php'; ?>

<!-- Floating Background Images -->
<div class="floating-images">
    <img src="img/3.png" class="floating-img" alt="Background Image 1" style="width: 200px; position: absolute; top: 10%; left: 5%;">
    <img src="img/4.png" class="floating-img" alt="Background Image 2" style="width: 220px; position: absolute; top: 20%; right: 10%;">
    <img src="img/2.png" class="floating-img" alt="Background Image 3" style="width: 250px; position: absolute; bottom: 15%; left: 20%;">
    <img src="img/3.png" class="floating-img" alt="Background Image 4" style="width: 180px; position: absolute; bottom: 5%; right: 25%;">
    <img src="img/4.png" class="floating-img" alt="Background Image 5" style="width: 200px; position: absolute; top: 3%; left: 42%;">
</div>

<!-- Main Container -->
<div class="container-custom flex-grow-1 d-flex align-items-center justify-content-center">
    <div class="row w-100 justify-content-center">
        <div class="col-md-6 d-flex align-items-center justify-content-center">
            <div class="login-container">
                <div class="logo-container">
                    <img src="img/ZoukiLogo.svg" alt="ZOUKI Logo" style="width: 120px; height: auto;">
                </div>

                <?php if(isset($_SESSION['error'])): ?>
                    <script>
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: '<?php echo $_SESSION['error']; ?>',
                            showConfirmButton: false,
                            timer: 3000
                        });
                    </script>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>

                <form method="POST" action="index.php">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control form-control-lg" placeholder="Enter Username" required />
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control form-control-lg" placeholder="Enter Password" required />
                    </div>

                    <div class="d-flex justify-content-between align-items-center">
                        <div class="form-check mb-0">
                            <input class="form-check-input me-2" type="checkbox" name="remember" id="rememberMe" />
                            <label class="form-check-label" for="rememberMe"> Remember me </label>
                        </div>
                        <a href="forgot_password.php" class="text-body">Forgot password?</a>
                    </div>

                    <div class="text-center text-lg-start mt-4 pt-2">
                        <button type="submit" class="btn btn-success btn-lg w-100">Login</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="mt-auto text-center py-3 w-100 position-relative footer">
    <div class="container">
        <p class="mb-0">Copyright © 2025. All rights reserved.</p>
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
