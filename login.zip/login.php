<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']); // Get raw password from form
    $remember = isset($_POST['remember']);

    $sql = "SELECT * FROM z_user WHERE username = ? AND status = 'active'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

        // Compare the entered password with the stored hash
        if (password_verify($password, $row['password'])) {
            $_SESSION['userID'] = $row['userID'];
            $_SESSION['username'] = $row['username'];

            // Set a Remember Me cookie
            if ($remember) {
                setcookie("username", $username, time() + (86400 * 30), "/");
            }

            echo "<script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Login Successful',
                        text: 'Redirecting...',
                        showConfirmButton: false,
                        timer: 2000
                    }).then(() => { window.location.href = 'dashboard.php'; });
                  </script>";
        } else {
            $_SESSION['error'] = "Invalid password!";
        }
    } else {
        $_SESSION['error'] = "Invalid username or account inactive!";
    }
}
?>
